A Pen created at CodePen.io. You can find this one at https://codepen.io/anug8628/pen/zMKBoQ.

 